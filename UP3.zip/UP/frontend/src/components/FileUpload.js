import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Import navigation from React Router

const FileUpload = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [uploadType, setUploadType] = useState("students"); // Default: Student Upload
  const navigate = useNavigate(); // Initialize navigation

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      setMessage("⚠️ Please select a file.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("❌ Authentication required. Please log in again.");
        return;
      }

      // ✅ Select API endpoint based on upload type
      const endpoint =
        uploadType === "students"
          ? "http://localhost:5000/api/admin/upload-students"
          : "http://localhost:5000/api/admin/upload-faculty";

      const response = await axios.post(endpoint, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token}`,
        },
      });

      console.log("✅ Upload successful:", response.data);
      setMessage(`✅ ${uploadType === "students" ? "Students" : "Faculty"} uploaded successfully!`);

      // ✅ Redirect to admin dashboard after 2 seconds
      setTimeout(() => navigate("/admin-dashboard"), 2000);
    } catch (error) {
      console.error("❌ Upload error:", error.response || error);
      setMessage(error.response?.data?.msg || "❌ Upload failed. Please try again.");
    }
  };

  return (
    <div className="container mt-5">
      <h2>Upload CSV File</h2>
      {message && <p className="text-info">{message}</p>}

      {/* ✅ Dropdown to choose upload type */}
      <select
        className="form-select mb-2"
        value={uploadType}
        onChange={(e) => setUploadType(e.target.value)}
      >
        <option value="students">📂 Upload Students</option>
        <option value="faculty">📂 Upload Faculty</option>
      </select>

      <form onSubmit={handleUpload}>
        <input
          type="file"
          className="form-control mb-2"
          onChange={handleFileChange}
          accept=".csv"
        />
        <button type="submit" className="btn btn-primary">📤 Upload</button>
      </form>
    </div>
  );
};

export default FileUpload;
