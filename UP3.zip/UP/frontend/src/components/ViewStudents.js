import React, { useEffect, useState } from "react";
import axios from "../api/api";

const ViewStudents = () => {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    axios.get("/students")
      .then((res) => setStudents(res.data))
      .catch((err) => console.error("Error fetching students:", err));
  }, []);

  return (
    <div>
      <h2>Students List</h2>
      <ul>{students.map((student) => <li key={student._id}>{student.name} - {student.registerNumber}</li>)}</ul>
    </div>
  );
};

export default ViewStudents;
