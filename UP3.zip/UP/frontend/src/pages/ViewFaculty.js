import React, { useState, useEffect, useCallback } from "react";
import api from "../api/api";

const ViewFaculty = () => {
  const [faculty, setFaculty] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // ✅ Wrap fetchFaculty in useCallback to prevent re-creation
  const fetchFaculty = useCallback(async () => {
    setLoading(true);
    try {
      const response = await api.get(`/admin/faculty?page=${page}&limit=10`);
      setFaculty(response.data.faculty);
      setTotalPages(Math.ceil(response.data.total / 10));
    } catch (err) {
      setError(err.response?.data?.msg || "❌ Failed to fetch faculty");
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => {
    fetchFaculty();
  }, [fetchFaculty]); // ✅ Fixed ESLint warning by using useCallback

  const filteredFaculty = faculty.filter(
    (f) => f.name.toLowerCase().includes(search.toLowerCase()) || f.facultyID.includes(search)
  );

  return (
    <div className="container mt-4">
      <h2 className="mb-3">👨‍🏫 Faculty List</h2>
      <input
        type="text"
        placeholder="🔍 Search by name or faculty ID"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="form-control mb-3"
      />
      {loading ? (
        <p>Loading faculty members...</p>
      ) : error ? (
        <p style={{ color: "red" }}>{error}</p>
      ) : filteredFaculty.length > 0 ? (
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Faculty ID</th>
              <th>Department</th>
            </tr>
          </thead>
          <tbody>
            {filteredFaculty.map((f) => (
              <tr key={f._id}>
                <td>{f.name}</td>
                <td>{f.facultyID}</td>
                <td>{f.department}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>⚠️ No faculty members found.</p>
      )}
      <div className="d-flex gap-2 mt-3">
        <button className="btn btn-secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>
          ⬅️ Previous
        </button>
        <span>Page {page} of {totalPages}</span>
        <button className="btn btn-secondary" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
          Next ➡️
        </button>
      </div>
    </div>
  );
};

export default ViewFaculty;
