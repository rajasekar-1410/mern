import React, { useEffect, useState } from "react";
import api from "../api/api";

const FacultyDashboard = () => {
  const [courses, setCourses] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const response = await api.get("/faculty/courses");
      setCourses(response.data.courses);
    } catch (err) {
      setError("❌ Failed to fetch courses");
    }
  };

  return (
    <div className="container mt-5">
      <h2>📚 Faculty Dashboard</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {courses.length > 0 ? (
        <ul className="list-group">
          {courses.map((course) => (
            <li key={course._id} className="list-group-item">
              <strong>{course.name}</strong> - {course.department}
            </li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No courses assigned.</p>
      )}
    </div>
  );
};

export default FacultyDashboard;
