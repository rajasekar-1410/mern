import React, { useState } from "react";
import api from "../api/api";

const UploadMaterial = () => {
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState({ text: "", type: "" });

  const allowedFileTypes = ["application/pdf", "application/msword", "image/jpeg", "image/png", "video/mp4"];

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];

    // ✅ File Type & Size Validation
    if (selectedFile && !allowedFileTypes.includes(selectedFile.type)) {
      setMessage({ text: "⚠️ Invalid file type. Allowed: PDF, DOCX, JPG, PNG, MP4", type: "error" });
      setFile(null);
      return;
    }
    if (selectedFile && selectedFile.size > 5 * 1024 * 1024) {
      setMessage({ text: "⚠️ File size too large! Max 5MB.", type: "error" });
      setFile(null);
      return;
    }

    setFile(selectedFile);
    setMessage({ text: "", type: "" });
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return setMessage({ text: "⚠️ Please select a file to upload.", type: "error" });

    const formData = new FormData();
    formData.append("file", file);
    formData.append("title", title);
    formData.append("subject", subject);

    try {
      await api.post("/materials/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setMessage({ text: "✅ File uploaded successfully!", type: "success" });
      setFile(null);
      setTitle("");
      setSubject("");
    } catch (error) {
      setMessage({ text: error.response?.data?.msg || "❌ File upload failed!", type: "error" });
    }
  };

  return (
    <div className="container mt-4">
      <h2>Upload Course Material</h2>
      
      {message.text && (
        <p style={{ color: message.type === "success" ? "green" : "red" }}>
          {message.text}
        </p>
      )}

      <form onSubmit={handleUpload}>
        <input type="text" placeholder="Material Title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        <input type="text" placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} required />
        <input type="file" onChange={handleFileChange} required />
        <button type="submit">Upload</button>
      </form>
    </div>
  );
};

export default UploadMaterial;
