import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const Login = () => {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ role: "student", identifier: "", password: "" });
  const [error, setError] = useState("");

  // ✅ Handle input changes
  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  // ✅ Handle Login
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/auth/login", credentials);
      localStorage.setItem("token", response.data.token);
      navigate(`/${credentials.role}-dashboard`);
    } catch (err) {
      setError(err.response?.data?.msg || "❌ Login failed!");
    }
  };

  return (
    <div className="container mt-5">
      <h2>🔐 Login</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleLogin}>
        <select name="role" onChange={handleChange} value={credentials.role} className="form-control mb-2">
          <option value="student">Student</option>
          <option value="faculty">Faculty</option>
          <option value="admin">Admin</option>
        </select>
        <input
          type="text"
          name="identifier"
          placeholder="Register Number / Faculty ID / Email"
          value={credentials.identifier}
          onChange={handleChange}
          className="form-control mb-2"
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={credentials.password}
          onChange={handleChange}
          className="form-control mb-2"
        />
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
      {/* ✅ Signup Button for Admins */}
      <div className="mt-3">
        <p>New Admin? <button onClick={() => navigate("/signup-admin")} className="btn btn-link">Signup Here</button></p>
      </div>
    </div>
  );
};

export default Login;
