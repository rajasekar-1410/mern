import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const EditFaculty = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [faculty, setFaculty] = useState({
    name: "",
    email: "",
    facultyID: "",
    department: "",
  });

  const [error, setError] = useState("");

  // ✅ Fetch Faculty Data
  useEffect(() => {
    const fetchFaculty = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/admin/faculty/${id}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setFaculty(response.data);
      } catch (err) {
        setError("❌ Error fetching faculty details.");
      }
    };
    fetchFaculty();
  }, [id]);

  // ✅ Handle Submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      await axios.put(`http://localhost:5000/api/admin/faculty/${id}`, faculty, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });

      alert("✅ Faculty updated successfully!");
      
      // ✅ Reload Faculty List Properly
      window.location.href = "/view-faculty";

    } catch (err) {
      setError("❌ Error updating faculty. Try again!");
    }
  };

  return (
    <div className="container mt-5">
      <h2>Edit Faculty</h2>
      {error && <p className="text-danger">{error}</p>}

      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Name:</label>
          <input
            type="text"
            className="form-control"
            value={faculty.name}
            onChange={(e) => setFaculty({ ...faculty, name: e.target.value })}
            required
          />
        </div>
        <div className="mb-3">
          <label>Email:</label>
          <input
            type="email"
            className="form-control"
            value={faculty.email}
            onChange={(e) => setFaculty({ ...faculty, email: e.target.value })}
            required
          />
        </div>
        <div className="mb-3">
          <label>Faculty ID:</label>
          <input
            type="text"
            className="form-control"
            value={faculty.facultyID}
            onChange={(e) => setFaculty({ ...faculty, facultyID: e.target.value })}
            required
          />
        </div>
        <div className="mb-3">
          <label>Department:</label>
          <input
            type="text"
            className="form-control"
            value={faculty.department}
            onChange={(e) => setFaculty({ ...faculty, department: e.target.value })}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary">Update Faculty</button>
      </form>
    </div>
  );
};

export default EditFaculty;
