import React, { useState, useEffect } from "react";
import api from "../api/api";

const ViewStudents = () => {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      const response = await api.get(`/admin/students?page=${page}&limit=10`);
      setStudents(response.data.students);
      setTotalPages(Math.ceil(response.data.total / 10));
    } catch (err) {
      setError(err.response?.data?.msg || "❌ Failed to fetch students");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]); // ✅ Fixed ESLint dependency warning

  const filteredStudents = students.filter(
    (s) => s.name.toLowerCase().includes(search.toLowerCase()) || s.registerNumber.includes(search)
  );

  return (
    <div className="container mt-4">
      <h2 className="mb-3">📋 Student List</h2>
      <input
        type="text"
        placeholder="🔍 Search by name or register number"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="form-control mb-3"
      />
      {loading ? (
        <p>Loading students...</p>
      ) : error ? (
        <p style={{ color: "red" }}>{error}</p>
      ) : filteredStudents.length > 0 ? (
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Register Number</th>
              <th>Department</th>
            </tr>
          </thead>
          <tbody>
            {filteredStudents.map((s) => (
              <tr key={s._id}>
                <td>{s.name}</td>
                <td>{s.registerNumber}</td>
                <td>{s.department}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>⚠️ No students found.</p>
      )}
      <div className="d-flex gap-2 mt-3">
        <button className="btn btn-secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>
          ⬅️ Previous
        </button>
        <span>Page {page} of {totalPages}</span>
        <button className="btn btn-secondary" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
          Next ➡️
        </button>
      </div>
    </div>
  );
};

export default ViewStudents;
