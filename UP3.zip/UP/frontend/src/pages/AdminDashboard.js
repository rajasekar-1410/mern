import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ students: 0, faculty: 0, materials: 0 });

  useEffect(() => {
    // ✅ Fetch admin stats on page load
    const fetchStats = async () => {
      try {
        const res = await api.get("/admin/stats");
        setStats(res.data);
      } catch (error) {
        console.error("❌ Error fetching stats:", error.response?.data?.msg || error.message);
      }
    };
    fetchStats();
  }, []);

  // ✅ Logout function
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Welcome, Admin</h2>
      <p>You can manage students, teachers, and system settings here.</p>

      {/* ✅ Admin Statistics */}
      <div className="row mb-4">
        <div className="col-md-4">
          <div className="card text-center p-3">
            <h5>👨‍🎓 Students</h5>
            <p>{stats.students}</p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card text-center p-3">
            <h5>👩‍🏫 Faculty</h5>
            <p>{stats.faculty}</p>
          </div>
        </div>
        <div className="col-md-4">
          <div className="card text-center p-3">
            <h5>📚 Materials</h5>
            <p>{stats.materials}</p>
          </div>
        </div>
      </div>

      {/* ✅ Quick Actions */}
      <div className="d-flex gap-3">
        <button className="btn btn-primary" onClick={() => navigate("/add-student")}>
          ➕ Add Student
        </button>
        <button className="btn btn-secondary" onClick={() => navigate("/add-faculty")}>
          ➕ Add Faculty
        </button>
      </div>

      {/* ✅ Manage Data Section */}
      <div className="mt-4">
        <h4>📚 Manage Data</h4>
        <ul>
          <li>
            <button className="btn btn-link" onClick={() => navigate("/view-students")}>
              📋 View Students
            </button>
          </li>
          <li>
            <button className="btn btn-link" onClick={() => navigate("/view-faculty")}>
              📋 View Faculty
            </button>
          </li>
          <li>
            <button className="btn btn-link" onClick={() => navigate("/upload-material")}>
              ⬆️ Upload Materials
            </button>
          </li>
          <li>
            <button className="btn btn-link" onClick={() => navigate("/view-notices")}>
              📰 View Notices
            </button>
          </li>
          <li>
            <button className="btn btn-link" onClick={() => navigate("/view-timetable")}>
              📅 View Timetable
            </button>
          </li>
        </ul>
      </div>

      {/* ✅ Logout Button */}
      <button className="btn btn-danger mt-3" onClick={handleLogout}>
        🚪 Logout
      </button>
    </div>
  );
};

export default AdminDashboard;
