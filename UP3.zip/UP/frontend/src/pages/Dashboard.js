import React, { useEffect, useState } from "react";
import api from "../api/api";

const Dashboard = () => {
  const [students, setStudents] = useState([]);
  const [faculty, setFaculty] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const studentsRes = await api.get("/admin/students");
      const facultyRes = await api.get("/admin/faculty");
      setStudents(studentsRes.data.students);
      setFaculty(facultyRes.data.faculty);
    } catch (err) {
      setError("❌ Failed to fetch dashboard data");
    }
  };

  return (
    <div className="container mt-5">
      <h2>📊 Dashboard</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <p>👨‍🎓 Total Students: {students.length}</p>
      <p>👨‍🏫 Total Faculty: {faculty.length}</p>
    </div>
  );
};

export default Dashboard;
