import React, { useState, useEffect } from "react";
import api from "../api/api";

const ViewTimetable = () => {
  const [timetable, setTimetable] = useState([]);
  const [error, setError] = useState("");

  const fetchTimetable = async () => {
    try {
      const response = await api.get("/student/timetable");
      setTimetable(sortByDay(response.data));
    } catch (err) {
      setError(err.response?.data?.msg || "❌ Failed to fetch timetable");
    }
  };

  useEffect(() => {
    fetchTimetable();
  }, [fetchTimetable]); // ✅ Fixed ESLint dependency warning

  const sortByDay = (data) => {
    const dayOrder = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return data.sort((a, b) => dayOrder.indexOf(a.day) - dayOrder.indexOf(b.day));
  };

  const formatTime = (timeString) => {
    const options = { hour: "2-digit", minute: "2-digit", hour12: true };
    return new Date(timeString).toLocaleTimeString("en-US", options);
  };

  return (
    <div className="container mt-5">
      <h2>📅 Timetable</h2>
      {error ? (
        <p style={{ color: "red" }}>{error}</p>
      ) : timetable.length > 0 ? (
        <ul className="list-group">
          {timetable.map((entry) => (
            <li key={entry._id} className="list-group-item">
              <strong>{entry.day}:</strong> {entry.subject}
              <br />⏰ {formatTime(entry.startTime)} - {formatTime(entry.endTime)}
            </li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No timetable available.</p>
      )}
    </div>
  );
};

export default ViewTimetable;
