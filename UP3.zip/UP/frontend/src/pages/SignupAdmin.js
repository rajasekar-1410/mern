import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const SignupAdmin = () => {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState({ name: "", email: "", password: "" });
  const [message, setMessage] = useState({ text: "", type: "" });

  // ✅ Handle input changes
  const handleChange = (e) => {
    setAdmin({ ...admin, [e.target.name]: e.target.value });
  };

  // ✅ Handle Admin Signup
  const handleSignup = async (e) => {
    e.preventDefault();

    if (!admin.name || !admin.email || !admin.password) {
      setMessage({ text: "⚠️ All fields are required!", type: "error" });
      return;
    }

    try {
      await api.post("/auth/admin-signup", admin);
      setMessage({ text: "✅ Admin registered successfully!", type: "success" });
      setTimeout(() => navigate("/"), 2000); // Redirect to login after 2 seconds
    } catch (error) {
      setMessage({ text: error.response?.data?.msg || "❌ Signup failed!", type: "error" });
    }
  };

  return (
    <div className="container mt-5">
      <h2>🛠️ Admin Signup</h2>
      {message.text && (
        <p style={{ color: message.type === "success" ? "green" : "red" }}>{message.text}</p>
      )}
      <form onSubmit={handleSignup}>
        <input type="text" name="name" placeholder="Full Name" value={admin.name} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email" value={admin.email} onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" value={admin.password} onChange={handleChange} required />
        <button type="submit">Signup</button>
      </form>
    </div>
  );
};

export default SignupAdmin;