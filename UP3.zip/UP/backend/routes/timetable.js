const express = require("express");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");
const Timetable = require("../models/Timetable");

const router = express.Router();

/* ==========================
 ✅ ADD TIMETABLE ENTRY (Admin Only)
============================== */
router.post("/timetables", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
  try {
    const { course, day, time, faculty } = req.body;

    if (!course || !day || !time || !faculty) {
      return res.status(400).json({ msg: "⚠️ Course, Day, Time, and Faculty are required!" });
    }

    const newTimetableEntry = new Timetable({ course, day, time, faculty });
    await newTimetableEntry.save();

    res.status(201).json({ msg: "✅ Timetable entry added successfully!", timetable: newTimetableEntry });
  } catch (error) {
    console.error("❌ Add Timetable Error:", error);
    res.status(500).json({ msg: "❌ Server Error" });
  }
});

/* ==========================
 ✅ GET TIMETABLES (All Users) - WITH PAGINATION
============================== */
router.get("/timetables", async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const timetables = await Timetable.find()
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    res.json({ timetables, total: await Timetable.countDocuments() });
  } catch (error) {
    console.error("❌ Fetch Timetables Error:", error);
    res.status(500).json({ msg: "❌ Server Error" });
  }
});

module.exports = router;
