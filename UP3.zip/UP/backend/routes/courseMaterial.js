const express = require("express");
const multer = require("multer");
const path = require("path");
const CourseMaterial = require("../models/CourseMaterial");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");

const router = express.Router();

// ✅ Configure file storage
const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

/* ==========================
  ✅ COURSE MATERIAL ROUTES
============================== */

// ✅ Upload Course Material
router.post("/materials/upload", authMiddleware, roleMiddleware(["admin", "faculty"]), upload.single("file"), async (req, res) => {
  try {
    const { title, subject } = req.body;
    const fileUrl = `/uploads/${req.file.filename}`;

    const newMaterial = new CourseMaterial({
      title,
      subject,
      fileUrl,
      uploadedBy: req.user.id,
    });

    await newMaterial.save();
    res.status(201).json({ msg: "✅ File uploaded successfully!", material: newMaterial });
  } catch (error) {
    res.status(500).json({ msg: "❌ File upload error", error: error.message });
  }
});

// ✅ Get All Course Materials
router.get("/materials", authMiddleware, async (req, res) => {
  try {
    const materials = await CourseMaterial.find().populate("uploadedBy", "name");
    res.json({ materials });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error fetching materials", error: error.message });
  }
});

module.exports = router;
