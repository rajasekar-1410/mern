const express = require("express");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");
const Student = require("../models/Student");
const Marks = require("../models/Marks");
const Timetable = require("../models/Timetable");

const router = express.Router();

/* ==========================
  ✅ STUDENT MARKS ROUTE
============================== */

// ✅ Get Student Marks
router.get("/student/marks", authMiddleware, roleMiddleware(["student"]), async (req, res) => {
  try {
    const marks = await Marks.find({ student: req.user.id });
    res.json({ marks });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error fetching marks", error: error.message });
  }
});

/* ==========================
  ✅ STUDENT TIMETABLE ROUTE
============================== */

// ✅ Get Student Timetable
router.get("/student/timetable", authMiddleware, roleMiddleware(["student"]), async (req, res) => {
  try {
    const timetable = await Timetable.find({ department: req.user.department });
    res.json({ timetable });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error fetching timetable", error: error.message });
  }
});

module.exports = router;
