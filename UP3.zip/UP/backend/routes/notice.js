const express = require("express");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");
const Notice = require("../models/Notice");

const router = express.Router();

/* ==========================
 ✅ ADD NOTICE (Admin Only)
============================== */
router.post("/notices", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
  try {
    const { title, content } = req.body;

    if (!title || !content) {
      return res.status(400).json({ msg: "⚠️ Title and Content are required!" });
    }

    const newNotice = new Notice({ title, content });
    await newNotice.save();

    res.status(201).json({ msg: "✅ Notice added successfully!", notice: newNotice });
  } catch (error) {
    console.error("❌ Add Notice Error:", error);
    res.status(500).json({ msg: "❌ Server Error" });
  }
});

/* ==========================
 ✅ GET NOTICES (All Users) - WITH PAGINATION
============================== */
router.get("/notices", async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const notices = await Notice.find()
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    res.json({ notices, total: await Notice.countDocuments() });
  } catch (error) {
    console.error("❌ Fetch Notices Error:", error);
    res.status(500).json({ msg: "❌ Server Error" });
  }
});

module.exports = router;
