const mongoose = require("mongoose");

const NoticeSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  date: { type: Date, default: Date.now },
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  priority: { type: String, enum: ["urgent", "general", "info"], default: "general" }, // ✅ Added priority field
  fileUrl: { type: String, default: "" }, // ✅ Added optional file attachment support
});

module.exports = mongoose.model("Notice", NoticeSchema);
