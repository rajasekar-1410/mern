const jwt = require("jsonwebtoken");

// ✅ Middleware to verify JWT token
const authMiddleware = (req, res, next) => {
  const token = req.header("Authorization");

  if (!token) {
    return res.status(401).json({ msg: "⚠️ No token provided. Access denied." });
  }

  try {
    // ✅ Extract token after "Bearer "
    const parts = token.split(" ");
    if (parts.length !== 2 || parts[0] !== "Bearer") {
      return res.status(401).json({ msg: "⚠️ Invalid token format. Use 'Bearer <token>'" });
    }

    const extractedToken = parts[1];
    const decoded = jwt.verify(extractedToken, process.env.JWT_SECRET);

    // ✅ Ensure the user payload exists
    if (!decoded.user) {
      return res.status(401).json({ msg: "⚠️ Invalid token payload. User data missing." });
    }

    req.user = decoded.user;
    next();
  } catch (err) {
    console.error("❌ JWT Verification Error:", err.message);
    
    if (err.name === "TokenExpiredError") {
      return res.status(401).json({ msg: "❌ Session expired. Please log in again." });
    }

    res.status(401).json({ msg: "❌ Invalid or expired token. Please log in again." });
  }
};

// ✅ Middleware for Role-Based Access Control
const roleMiddleware = (roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    console.warn(`🚫 Access denied: User role '${req.user?.role || "undefined"}' tried to access '${req.originalUrl}'`);
    return res.status(403).json({ msg: "🚫 Access Denied. You do not have permission." });
  }
  next();
};

module.exports = { authMiddleware, roleMiddleware };
