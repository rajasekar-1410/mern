const mongoose = require("mongoose");

const MarksSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Student",
    required: true,
  },
  subject: {
    type: String,
    required: true,
  },
  internalMarks: {
    type: Number,
    required: true,
    min: 0,
    max: 50,
  },
  externalMarks: {
    type: Number,
    required: true,
    min: 0,
    max: 100,
  },
  totalMarks: {
    type: Number,
    required: true,
  },
  grade: {
    type: String,
    required: true,
  }
}, { timestamps: true });

module.exports = mongoose.model("Marks", MarksSchema);
