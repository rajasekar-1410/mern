const mongoose = require("mongoose");

const TimetableSchema = new mongoose.Schema({
  day: { type: String, required: true, enum: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] },
  course: { type: String, required: true }, // ✅ Added course/department field
  subject: { type: String, required: true },
  startTime: { type: Date, required: true }, // ✅ Changed to Date object
  endTime: { type: Date, required: true }, // ✅ Changed to Date object
  faculty: { type: mongoose.Schema.Types.ObjectId, ref: "Faculty", required: true } // ✅ Changed to reference Faculty model
});

module.exports = mongoose.model("Timetable", TimetableSchema);
