const mongoose = require("mongoose");

const CourseMaterialSchema = new mongoose.Schema({
  title: { type: String, required: true },
  subject: { type: String, required: true },
  fileUrl: { type: String, required: true }, // ✅ Ensure valid paths in /uploads/
  fileType: { type: String, required: true }, // ✅ Added file type field
  fileSize: { type: Number, required: true }, // ✅ Store file size in KB
  uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  uploadedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("CourseMaterial", CourseMaterialSchema);
