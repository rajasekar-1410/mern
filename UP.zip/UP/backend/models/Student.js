const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const StudentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    registerNumber: { type: String, unique: true, required: true },
    email: { type: String, required: true, unique: true },
    department: { type: String, required: true },
    dob: { type: Date, required: true }, // ✅ Changed from String to Date
    password: { type: String, required: true }, // ✅ Stores hashed DOB as password
    role: { type: String, default: "student" }
  },
  { timestamps: true }
);

// ✅ Hash DOB only if changed before saving
StudentSchema.pre("save", async function (next) {
  if (!this.isModified("dob")) return next();  // ✅ Hash only when DOB changes

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.dob.toISOString().split("T")[0], salt); // ✅ Hash DOB in YYYY-MM-DD format
    next();
  } catch (error) {
    next(error);
  }
});

// ✅ Method to Compare Password
StudentSchema.methods.comparePassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model("Student", StudentSchema);
