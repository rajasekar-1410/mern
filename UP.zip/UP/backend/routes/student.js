const express = require("express");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");
const Student = require("../models/Student");
const Marks = require("../models/Marks");
const Timetable = require("../models/Timetable");

const router = express.Router();

/* ==========================
  ✅ STUDENT MANAGEMENT ROUTES
============================== */

// ✅ Get All Students
router.get("/students", authMiddleware, async (req, res) => {
  try {
    const students = await Student.find().select("-password"); // Exclude passwords
    res.json(students);
  } catch (err) {
    res.status(500).json({ msg: "❌ Error fetching students", error: err.message });
  }
});

// ✅ Add a Student
router.post("/students", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
  try {
    const { name, registerNumber, email, department, dob } = req.body;
    if (!name || !registerNumber || !dob || !department) {
      return res.status(400).json({ msg: "⚠️ All fields are required!" });
    }

    const newStudent = new Student({ name, registerNumber, email, department, dob });
    await newStudent.save();

    res.status(201).json({ msg: "✅ Student added successfully!", student: newStudent });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error adding student", error: error.message });
  }
});

/* ==========================
  ✅ STUDENT TIMETABLE ROUTE
============================== */

// ✅ Get Student Timetable
router.get("/student/timetable", authMiddleware, roleMiddleware(["student"]), async (req, res) => {
  try {
    const timetable = await Timetable.find({ department: req.user.department });
    res.json({ timetable });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error fetching timetable", error: error.message });
  }
});

module.exports = router;
