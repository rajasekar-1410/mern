const express = require("express");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");
const Attendance = require("../models/Attendance");
const Faculty = require("../models/Faculty");
const Student = require("../models/Student");

const router = express.Router();

/* ==========================
  ✅ FACULTY ATTENDANCE ROUTE
============================== */

// ✅ Mark Attendance
router.post("/faculty/attendance", authMiddleware, roleMiddleware(["faculty"]), async (req, res) => {
  try {
    const { studentId, status } = req.body;
    if (!studentId || !status) {
      return res.status(400).json({ msg: "⚠️ Student ID and status are required!" });
    }

    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ msg: "⚠️ Student not found!" });

    const newAttendance = new Attendance({
      student: studentId,
      faculty: req.user.id,
      status,
      date: new Date(),
    });

    await newAttendance.save();
    res.status(201).json({ msg: "✅ Attendance marked successfully!", attendance: newAttendance });
  } catch (error) {
    res.status(500).json({ msg: "❌ Attendance marking error", error: error.message });
  }
});

module.exports = router;
