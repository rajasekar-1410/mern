const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { authMiddleware } = require("../middleware/authMiddleware");

const router = express.Router();

/* ==========================
  ✅ USER LOGIN (Fixed)
============================== */
router.post("/login", async (req, res) => {
  try {
    const { identifier, password, role } = req.body;
    console.log("🔍 Checking user:", identifier, "Role:", role);

    // ✅ Find user based on role
    let user;
    if (role === "admin") {
      user = await User.findOne({ email: identifier });
    } else if (role === "student") {
      user = await Student.findOne({ registerNumber: identifier });
    } else if (role === "faculty") {
      user = await Faculty.findOne({ facultyID: identifier });
    }

    if (!user) {
      console.log("❌ User not found");
      return res.status(400).json({ msg: "❌ Invalid credentials" });
    }

    console.log("✅ User found:", user);

    // ✅ Compare password with hashed password in database
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.log("❌ Password does not match");
      return res.status(400).json({ msg: "❌ Invalid credentials" });
    }

    console.log("✅ Password Matched! Logging in...");

    // ✅ Generate JWT Token
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "1d" });

    res.json({ token, user: { id: user._id, name: user.name, email: user.email || identifier, role: user.role } });

  } catch (error) {
    console.error("❌ Login error:", error.message);
    res.status(500).json({ msg: "❌ Login error", error: error.message });
  }
});


/* ==========================
  ✅ USER REGISTRATION (Fixed)
============================== */
router.post("/auth/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ msg: "⚠️ User already exists!" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, password: hashedPassword, role });
    await newUser.save();

    res.status(201).json({ msg: "✅ Registration successful!" });
  } catch (error) {
    res.status(500).json({ msg: "❌ Registration error", error: error.message });
  }
});

/* ==========================
  ✅ ADMIN SIGNUP (Newly Added)
============================== */
router.post("/admin-signup", async (req, res) => {
  try {
    const { name, email, password, institution } = req.body;

    // ✅ Check if an admin already exists for this institution
    const existingAdmin = await User.findOne({ role: "admin", institution });
    if (existingAdmin) return res.status(400).json({ msg: "❌ An admin already exists for this institution!" });

    // ✅ Hash Password
    const hashedPassword = await bcrypt.hash(password, 10);

    // ✅ Create New Admin
    const newAdmin = new User({ name, email, password: hashedPassword, institution, role: "admin" });
    await newAdmin.save();

    res.status(201).json({ msg: "✅ Admin registered successfully!" });
  } catch (error) {
    res.status(500).json({ msg: "❌ Admin signup error", error: error.message });
  }
});

module.exports = router;
