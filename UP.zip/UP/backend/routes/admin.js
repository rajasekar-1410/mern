const express = require("express");
const { authMiddleware, roleMiddleware } = require("../middleware/authMiddleware");
const Student = require("../models/Student");
const Faculty = require("../models/Faculty");

const router = express.Router();

/* ==========================
  ✅ ADMIN DASHBOARD STATS ROUTE
============================== */

// ✅ Fetch Admin Dashboard Stats
router.get("/stats", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
  try {
    const totalStudents = await Student.countDocuments();
    const totalFaculty = await Faculty.countDocuments();

    const stats = {
      totalStudents,
      totalFaculty,
      totalCourses: 10, // Placeholder, update with actual course count if applicable
    };

    res.json(stats);
  } catch (error) {
    res.status(500).json({ msg: "❌ Error fetching admin stats", error: error.message });
  }
});

/* ==========================
  ✅ STUDENT MANAGEMENT ROUTES
============================== */

// ✅ Update Student Details
router.put("/admin/students/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(req.params.id, req.body, { new: true }).select("-password");
    if (!student) return res.status(404).json({ msg: "⚠️ Student not found" });
    res.json({ msg: "✅ Student updated successfully!", student });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error updating student", error: error.message });
  }
});

/* ==========================
  ✅ FACULTY MANAGEMENT ROUTES
============================== */

// ✅ Update Faculty Details
router.put("/admin/faculty/:id", authMiddleware, roleMiddleware(["admin"]), async (req, res) => {
  try {
    const faculty = await Faculty.findByIdAndUpdate(req.params.id, req.body, { new: true }).select("-password");
    if (!faculty) return res.status(404).json({ msg: "⚠️ Faculty not found" });
    res.json({ msg: "✅ Faculty updated successfully!", faculty });
  } catch (error) {
    res.status(500).json({ msg: "❌ Error updating faculty", error: error.message });
  }
});

module.exports = router;
