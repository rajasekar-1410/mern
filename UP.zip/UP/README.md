# MERN College Management System

## 📌 Project Overview
This is a **MERN Stack-based College Management System** designed to manage students, faculty, courses, materials, attendance, and more. The system is built to function like **MyCamu** but with enhanced efficiency and scalability.

## 🚀 Features Implemented
- **Admin Features:**  
  ✅ Add Students & Faculty  
  ✅ Manage Classes & Subjects  
  ✅ Upload Notices & Timetables  
  ✅ Oversee System Settings  

- **Teacher Features:**  
  ✅ Take Attendance  
  ✅ Upload Course Materials  
  ✅ Generate Reports  
  ✅ Assess Student Performance  

- **Student Features:**  
  ✅ View Internal & External Marks  
  ✅ Download Course Materials  
  ✅ View Notices & Timetables  
  ✅ Visualize Performance Data  

## 🛠 Technology Stack
- **Frontend:** React.js (with Tailwind CSS)
- **Backend:** Node.js, Express.js, MongoDB
- **Authentication:** JWT-based Authentication

## 📂 Folder Structure
```
mern-project/
│── backend/         # Node.js & Express.js Backend
│   ├── models/      # Database Models (MongoDB)
│   ├── routes/      # API Endpoints
│   ├── middleware/  # Authentication & File Upload Middleware
│   ├── server.js    # Main Server File
│── frontend/        # React.js Frontend
│   ├── src/         # Source Code
│   ├── components/  # UI Components
│   ├── api/         # API Call Handlers
│── README.md        # Project Documentation
```

## ⚙️ Installation Guide

### 1️⃣ Clone the Repository
```sh
git clone https://github.com/your-repo/MERN-College-Management.git
cd MERN-College-Management
```

### 2️⃣ Backend Setup
```sh
cd backend
npm install
npm start
```

### 3️⃣ Frontend Setup
```sh
cd frontend
npm install
npm start
```

### 4️⃣ Database Setup
- Install MongoDB and start it locally:  
  ```sh
  mongod --dbpath=/data/db
  ```
- Use MongoDB Compass to manage data.

## ✅ Running the Application
- Backend runs on **http://localhost:5000**
- Frontend runs on **http://localhost:3000**
- Login using:  
  **Admin:** admin@example.com / password  
  **Student:** Register Number & DOB  
  **Faculty:** Faculty ID & DOB

## 📞 Support & Issues
For any issues, feel free to contact or raise a GitHub issue.

---
**Developed by Rajasekar 🚀**
