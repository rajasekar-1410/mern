import React from "react";
import { Routes, Route } from "react-router-dom";
import Login from "./pages/Login";
import SignupAdmin from "./pages/SignupAdmin";
import AdminDashboard from "./pages/AdminDashboard";
import StudentDashboard from "./pages/StudentDashboard";
import FacultyDashboard from "./pages/FacultyDashboard";
import AddStudent from "./pages/AddStudent";
import ViewStudents from "./pages/ViewStudents";
import AddFaculty from "./pages/AddFaculty";
import ViewFaculty from "./pages/ViewFaculty";
import UploadMaterial from "./pages/UploadMaterial";
import DownloadMaterials from "./pages/DownloadMaterials";
import ViewMarks from "./pages/ViewMarks";
import Attendance from "./pages/Attendance";
import ViewNotices from "./pages/ViewNotices";
import ViewTimetable from "./pages/ViewTimetable";

const NotFound = () => (
  <div className="container text-center mt-5">
    <h2>🚫 Page Not Found</h2>
    <p>The page you are looking for does not exist.</p>
  </div>
);

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/signup-admin" element={<SignupAdmin />} />
      <Route path="/admin-dashboard" element={<AdminDashboard />} />
      <Route path="/faculty-dashboard" element={<FacultyDashboard />} />
      <Route path="/student-dashboard" element={<StudentDashboard />} />
      <Route path="/add-student" element={<AddStudent />} />
      <Route path="/view-students" element={<ViewStudents />} />
      <Route path="/add-faculty" element={<AddFaculty />} />
      <Route path="/view-faculty" element={<ViewFaculty />} />
      <Route path="/upload-material" element={<UploadMaterial />} />
      <Route path="/download-materials" element={<DownloadMaterials />} />
      <Route path="/view-marks" element={<ViewMarks />} />
      <Route path="/attendance" element={<Attendance />} />
      <Route path="/view-notices" element={<ViewNotices />} />
      <Route path="/view-timetable" element={<ViewTimetable />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;
