import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api"; // ✅ Ensures correct API handling

const Login = () => {
  const [role, setRole] = useState("student");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(""); // ✅ State for login errors
  const navigate = useNavigate(); // ✅ Navigation hook for redirecting

  const handleLogin = async (e) => {
    e.preventDefault();
    
    // ✅ Form Validation
    if (!identifier || !password) {
      setError("⚠️ Please enter both Identifier and Password.");
      return;
    }

    // ✅ Correct Payload Based on Role
    const payload = {
      role,
      ...(role === "admin"
        ? { email: identifier }
        : role === "student"
        ? { registerNumber: identifier }
        : { facultyID: identifier }), // ✅ Fixed faculty login
      password,
    };

    try {
      const res = await api.post("/auth/login", payload);
      localStorage.setItem("token", res.data.token);
      setError(""); // Clear any previous errors
      alert("✅ Login Successful!");
      // TODO: Redirect user based on role (e.g., dashboard)
    } catch (error) {
      setError(error.response?.data?.msg || "❌ Login failed!");
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <select onChange={(e) => setRole(e.target.value)}>
        <option value="student">Student</option>
        <option value="faculty">Faculty</option>
        <option value="admin">Admin</option>
      </select>
      <input
        type="text"
        placeholder={role === "admin" ? "Email" : role === "student" ? "Register Number" : "Faculty ID"}
        value={identifier}
        onChange={(e) => setIdentifier(e.target.value)}
      />
      <input type="password" placeholder="Date of Birth / Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
      {error && <p style={{ color: "red" }}>{error}</p>} {/* ✅ Error message displayed */}
      
      {/* ✅ Signup Button for Admin Registration */}
      {role === "admin" && (
        <button onClick={() => navigate("/signup-admin")} style={{ marginTop: "10px", background: "blue", color: "white" }}>
          Signup as Admin
        </button>
      )}
    </div>
  );
};

export default Login;
