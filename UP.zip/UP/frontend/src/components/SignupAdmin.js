import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const SignupAdmin = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    institution: ""
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    try {
      const res = await api.post("/auth/signup-admin", formData);
      setSuccess("✅ Admin registered successfully! Redirecting...");
      setTimeout(() => navigate("/"), 2000); // Redirect to login page
    } catch (error) {
      setError(error.response?.data?.msg || "❌ Signup failed!");
    }
  };

  return (
    <div>
      <h2>Admin Signup</h2>
      <form onSubmit={handleSignup}>
        <input type="text" name="name" placeholder="Full Name" value={formData.name} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
        <input type="text" name="institution" placeholder="Institution Name" value={formData.institution} onChange={handleChange} required />
        <button type="submit">Signup</button>
      </form>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {success && <p style={{ color: "green" }}>{success}</p>}
    </div>
  );
};

export default SignupAdmin;
