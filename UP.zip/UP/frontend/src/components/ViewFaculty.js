import React, { useEffect, useState } from "react";
import axios from "../api/api";

const ViewFaculty = () => {
  const [faculty, setFaculty] = useState([]);

  useEffect(() => {
    axios.get("/faculty")
      .then((res) => setFaculty(res.data))
      .catch((err) => console.error("Error fetching faculty:", err));
  }, []);

  return (
    <div>
      <h2>Faculty List</h2>
      <ul>{faculty.map((teacher) => <li key={teacher._id}>{teacher.name} - {teacher.facultyID}</li>)}</ul>
    </div>
  );
};

export default ViewFaculty;
