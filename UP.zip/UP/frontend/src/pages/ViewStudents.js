import React, { useEffect, useState, useCallback } from "react";
import api from "../api/api";

const ViewStudents = () => {
  const [students, setStudents] = useState([]);
  const [error, setError] = useState("");

  // ✅ Use useCallback to prevent infinite re-renders
  const fetchStudents = useCallback(async () => {
    try {
      const response = await api.get("/admin/students");
      setStudents(response.data);
    } catch (err) {
      setError("❌ Failed to fetch students. Please try again.");
    }
  }, []);

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]); // ✅ Dependency array now contains stable function reference

  return (
    <div>
      <h2>View Students</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {students.map((student) => (
          <li key={student._id}>{student.name} - {student.registerNumber}</li>
        ))}
      </ul>
    </div>
  );
};

export default ViewStudents;
