import React, { useEffect, useState } from "react";
import api from "../api/api";

const ViewMaterials = () => {
  const [materials, setMaterials] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchMaterials();
  }, []);

  const fetchMaterials = async () => {
    try {
      const response = await api.get("/materials");
      setMaterials(response.data.materials);
    } catch (err) {
      setError("❌ Failed to fetch materials");
    }
  };

  return (
    <div className="container mt-5">
      <h2>📚 Course Materials</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {materials.length > 0 ? (
        <ul className="list-group">
          {materials.map((material) => (
            <li key={material._id} className="list-group-item">
              <strong>{material.title}</strong> - {material.subject}
              <a href={material.fileUrl} download className="btn btn-primary btn-sm float-end">⬇️ Download</a>
            </li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No materials available.</p>
      )}
    </div>
  );
};

export default ViewMaterials;
