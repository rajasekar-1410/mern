import React, { useState, useEffect } from "react";
import api from "../api/api";

const AddStudent = () => {
  const [student, setStudent] = useState({
    name: "",
    registerNumber: "",
    email: "",
    department: "",
    dob: "",
  });

  const [message, setMessage] = useState({ text: "", type: "" });
  const [studentList, setStudentList] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchStudents();
  }, []);

  // ✅ Fetch students list
  const fetchStudents = async () => {
    setLoading(true);
    try {
      const response = await api.get("/students"); // ✅ Fixed API endpoint
      setStudentList(response.data);
    } catch (error) {
      console.error("❌ Error fetching students:", error.response?.data);
      setMessage({ text: "❌ Failed to fetch students. Please try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  // ✅ Handle input changes
  const handleChange = (e) => {
    setStudent({ ...student, [e.target.name]: e.target.value });
  };

  // ✅ Submit student data
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // ✅ Validation check
    if (!student.name || !student.registerNumber || !student.department || !student.dob) {
      setMessage({ text: "⚠️ Please fill all required fields.", type: "error" });
      return;
    }

    try {
      await api.post("/students", student); // ✅ Fixed API endpoint
      setMessage({ text: "✅ Student added successfully!", type: "success" });
      setStudent({ name: "", registerNumber: "", email: "", department: "", dob: "" });
      fetchStudents(); // Refresh list
    } catch (error) {
      setMessage({ text: error.response?.data?.msg || "❌ Error adding student.", type: "error" });
    }
  };

  return (
    <div className="container mt-4">
      <h2>Add Student</h2>
      
      {message.text && (
        <p style={{ color: message.type === "success" ? "green" : "red" }}>
          {message.text}
        </p>
      )}

      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Full Name" value={student.name} onChange={handleChange} required />
        <input type="text" name="registerNumber" placeholder="Register Number" value={student.registerNumber} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email (Optional)" value={student.email} onChange={handleChange} />
        <input type="text" name="department" placeholder="Department" value={student.department} onChange={handleChange} required />
        <input type="date" name="dob" placeholder="Date of Birth" value={student.dob} onChange={handleChange} required />
        <button type="submit">Add Student</button>
      </form>

      <h3 className="mt-4">Student List</h3>
      {loading ? <p>Loading...</p> : studentList.length > 0 ? (
        <ul>
          {studentList.map((s) => (
            <li key={s._id}>{s.name} ({s.registerNumber}) - {s.department}</li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No students found.</p>
      )}
    </div>
  );
};

export default AddStudent;
