import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const EditStudent = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [student, setStudent] = useState({ name: "", email: "", registerNumber: "", department: "" });

  useEffect(() => {
    fetchStudent();
  }, []);

  const fetchStudent = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get(`http://localhost:5000/api/admin/students/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setStudent(response.data);
    } catch (error) {
      console.error("❌ Error fetching student details:", error);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("token");
      await axios.put(`http://localhost:5000/api/admin/students/${id}`, student, {
        headers: { Authorization: `Bearer ${token}` },
      });
      alert("✅ Student updated successfully!");
      navigate("/students");
    } catch (error) {
      console.error("❌ Error updating student:", error);
    }
  };

  return (
    <div className="container mt-4">
      <h2>Edit Student</h2>
      <form onSubmit={handleUpdate}>
        <div className="mb-3">
          <label>Name:</label>
          <input type="text" className="form-control" value={student.name} onChange={(e) => setStudent({ ...student, name: e.target.value })} required />
        </div>
        <div className="mb-3">
          <label>Email:</label>
          <input type="email" className="form-control" value={student.email} onChange={(e) => setStudent({ ...student, email: e.target.value })} required />
        </div>
        <div className="mb-3">
          <label>Register Number:</label>
          <input type="text" className="form-control" value={student.registerNumber} readOnly />
        </div>
        <div className="mb-3">
          <label>Department:</label>
          <input type="text" className="form-control" value={student.department} onChange={(e) => setStudent({ ...student, department: e.target.value })} required />
        </div>
        <button type="submit" className="btn btn-success">Update</button>
      </form>
    </div>
  );
};

export default EditStudent;
