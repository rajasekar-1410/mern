import React, { useState, useEffect } from "react";
import api from "../api/api";

const AddFaculty = () => {
  const [faculty, setFaculty] = useState({
    name: "",
    facultyID: "",
    email: "",
    department: "",
    dob: "",
  });

  const [message, setMessage] = useState({ text: "", type: "" });
  const [facultyList, setFacultyList] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchFaculty();
  }, []);

  // ✅ Fetch faculty list
  const fetchFaculty = async () => {
    setLoading(true);
    try {
      const response = await api.get("/admin/faculty");
      setFacultyList(response.data);
    } catch (error) {
      console.error("❌ Error fetching faculty:", error.response?.data);
      setMessage({ text: "❌ Failed to fetch faculty. Please try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  // ✅ Handle input changes
  const handleChange = (e) => {
    setFaculty({ ...faculty, [e.target.name]: e.target.value });
  };

  // ✅ Submit faculty data
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // ✅ Validation check
    if (!faculty.name || !faculty.facultyID || !faculty.department || !faculty.dob) {
      setMessage({ text: "⚠️ Please fill all required fields.", type: "error" });
      return;
    }

    try {
      await api.post("/admin/faculty", faculty);
      setMessage({ text: "✅ Faculty added successfully!", type: "success" });
      setFaculty({ name: "", facultyID: "", email: "", department: "", dob: "" });
      fetchFaculty(); // Refresh list
    } catch (error) {
      setMessage({ text: error.response?.data?.msg || "❌ Error adding faculty.", type: "error" });
    }
  };

  return (
    <div className="container mt-4">
      <h2>Add Faculty</h2>
      
      {message.text && (
        <p style={{ color: message.type === "success" ? "green" : "red" }}>
          {message.text}
        </p>
      )}

      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Full Name" value={faculty.name} onChange={handleChange} required />
        <input type="text" name="facultyID" placeholder="Faculty ID" value={faculty.facultyID} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email (Optional)" value={faculty.email} onChange={handleChange} />
        <input type="text" name="department" placeholder="Department" value={faculty.department} onChange={handleChange} required />
        <input type="date" name="dob" placeholder="Date of Birth" value={faculty.dob} onChange={handleChange} required />
        <button type="submit">Add Faculty</button>
      </form>

      <h3 className="mt-4">Faculty List</h3>
      {loading ? <p>Loading...</p> : facultyList.length > 0 ? (
        <ul>
          {facultyList.map((f) => (
            <li key={f._id}>{f.name} ({f.facultyID}) - {f.department}</li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No faculty found.</p>
      )}
    </div>
  );
};

export default AddFaculty;
