import React, { useState, useEffect } from "react";
import api from "../api/api";

const ViewMarks = () => {
  const [marks, setMarks] = useState([]);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    fetchMarks();
  }, []);

  // ✅ Fetch student marks
  const fetchMarks = async () => {
    try {
      const response = await api.get("/student/marks");
      setMarks(response.data);
    } catch (error) {
      setError(error.response?.data?.msg || "❌ Unable to fetch marks. Please log in again.");
    }
  };

  // ✅ Search Function
  const filteredMarks = marks.filter((mark) =>
    mark.subject.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container mt-5">
      <h2>📊 View Marks</h2>

      {/* ✅ Search Bar */}
      <input
        type="text"
        placeholder="🔍 Search by subject"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="form-control mb-3"
      />

      {error ? (
        <p style={{ color: "red" }}>{error}</p>
      ) : marks.length > 0 ? (
        <ul className="list-group">
          {filteredMarks.map((mark) => (
            <li key={mark._id} className="list-group-item">
              <strong>{mark.subject}:</strong> {mark.score} / {mark.total}
            </li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No marks available.</p>
      )}
    </div>
  );
};

export default ViewMarks;
