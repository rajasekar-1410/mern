import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const SignupAdmin = () => {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState({ name: "", email: "", password: "", institution: "" });
  const [message, setMessage] = useState("");

  // ✅ Handle input changes
  const handleChange = (e) => {
    setAdmin({ ...admin, [e.target.name]: e.target.value });
  };

  // ✅ Handle Admin Signup
  const handleSignup = async (e) => {
    e.preventDefault();

    if (!admin.name || !admin.email || !admin.password || !admin.institution) {
      setMessage("⚠️ All fields are required!");
      return;
    }

    try {
      await api.post("/auth/admin-signup", admin);
      setMessage("✅ Admin registered successfully!");
      setTimeout(() => navigate("/"), 2000); // Redirect to login after 2 seconds
    } catch (error) {
      setMessage(error.response?.data?.msg || "❌ Signup failed!");
    }
  };

  return (
    <div className="container mt-5">
      <h2>🛠️ Admin Signup</h2>
      {message && <p style={{ color: message.includes("❌") ? "red" : "green" }}>{message}</p>}
      <form onSubmit={handleSignup}>
        <input type="text" name="name" placeholder="Full Name" value={admin.name} onChange={handleChange} required />
        <input type="email" name="email" placeholder="Email" value={admin.email} onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" value={admin.password} onChange={handleChange} required />
        <input type="text" name="institution" placeholder="Institution Name" value={admin.institution} onChange={handleChange} required />
        <button type="submit">Signup</button>
      </form>
    </div>
  );
};

export default SignupAdmin;
