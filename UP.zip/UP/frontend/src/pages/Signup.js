import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const SignupAdmin = () => {
  const navigate = useNavigate();
  const [adminData, setAdminData] = useState({ name: "", email: "", password: "", institution: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // ✅ Handle input changes
  const handleChange = (e) => {
    setAdminData({ ...adminData, [e.target.name]: e.target.value });
  };

  // ✅ Handle Admin Signup
  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/auth/admin-signup", adminData);
      setSuccess(response.data.msg);
      setError("");
      setTimeout(() => navigate("/"), 2000); // Redirect after success
    } catch (err) {
      setError(err.response?.data?.msg || "❌ Signup failed!");
      setSuccess("");
    }
  };

  return (
    <div className="container mt-5">
      <h2>📝 Admin Signup</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {success && <p style={{ color: "green" }}>{success}</p>}
      <form onSubmit={handleSignup}>
        <input type="text" name="name" placeholder="Admin Name" value={adminData.name} onChange={handleChange} className="form-control mb-2" required />
        <input type="email" name="email" placeholder="Email" value={adminData.email} onChange={handleChange} className="form-control mb-2" required />
        <input type="password" name="password" placeholder="Password" value={adminData.password} onChange={handleChange} className="form-control mb-2" required />
        <input type="text" name="institution" placeholder="Institution Name" value={adminData.institution} onChange={handleChange} className="form-control mb-2" required />
        <button type="submit" className="btn btn-primary">Signup</button>
      </form>
    </div>
  );
};

export default SignupAdmin;
