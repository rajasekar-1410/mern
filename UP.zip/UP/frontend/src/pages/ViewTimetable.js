import React, { useEffect, useState, useCallback } from "react";
import api from "../api/api";

const ViewTimetable = () => {
  const [timetable, setTimetable] = useState([]);
  const [error, setError] = useState("");

  // ✅ Use useCallback to prevent infinite re-renders
  const fetchTimetable = useCallback(async () => {
    try {
      const response = await api.get("/timetable");
      setTimetable(response.data);
    } catch (err) {
      setError("❌ Failed to fetch timetable. Please try again.");
    }
  }, []);

  useEffect(() => {
    fetchTimetable();
  }, [fetchTimetable]); // ✅ Dependency array now contains stable function reference

  return (
    <div>
      <h2>View Timetable</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <ul>
        {timetable.map((entry) => (
          <li key={entry._id}>{entry.date} - {entry.subject}</li>
        ))}
      </ul>
    </div>
  );
};

export default ViewTimetable;
