import React, { useState, useEffect } from "react";
import api from "../api/api";

const Attendance = () => {
  const [attendance, setAttendance] = useState([]);
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState("");
  const [status, setStatus] = useState("Present");
  const [search, setSearch] = useState("");

  useEffect(() => {
    fetchAttendance();
    fetchStudents();
  }, []);

  // ✅ Fetch Attendance Records
  const fetchAttendance = async () => {
    try {
      const response = await api.get("/faculty/attendance");
      setAttendance(response.data);
    } catch (error) {
      console.error("❌ Error fetching attendance:", error.response?.data?.msg || error.message);
    }
  };

  // ✅ Fetch Student List
  const fetchStudents = async () => {
    try {
      const response = await api.get("/admin/students");
      setStudents(response.data);
    } catch (error) {
      console.error("❌ Error fetching students:", error.response?.data?.msg || error.message);
    }
  };

  // ✅ Mark Attendance
  const markAttendance = async () => {
    if (!selectedStudent) return alert("⚠️ Please select a student.");

    try {
      await api.post("/faculty/attendance", {
        studentId: selectedStudent,
        status,
      });

      alert("✅ Attendance marked successfully!");
      fetchAttendance(); // Refresh list
    } catch (error) {
      console.error("❌ Error marking attendance:", error.response?.data?.msg || error.message);
    }
  };

  // ✅ Search Function
  const filteredAttendance = attendance.filter(
    (record) =>
      record.studentName.toLowerCase().includes(search.toLowerCase()) ||
      record.date.includes(search)
  );

  return (
    <div className="container mt-5">
      <h2>📅 Attendance Management</h2>

      {/* ✅ Search Bar */}
      <input
        type="text"
        placeholder="🔍 Search by student name or date"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="form-control mb-3"
      />

      {/* ✅ Mark Attendance */}
      <div className="mb-4">
        <h4>✅ Mark Attendance</h4>
        <select className="form-control mb-2" onChange={(e) => setSelectedStudent(e.target.value)}>
          <option value="">Select Student</option>
          {students.map((student) => (
            <option key={student._id} value={student._id}>
              {student.name} ({student.registerNumber})
            </option>
          ))}
        </select>
        <select className="form-control mb-2" onChange={(e) => setStatus(e.target.value)}>
          <option value="Present">Present</option>
          <option value="Absent">Absent</option>
        </select>
        <button className="btn btn-primary" onClick={markAttendance}>
          ✅ Submit Attendance
        </button>
      </div>

      {/* ✅ Attendance Records */}
      <h4>📋 Attendance Records</h4>
      {filteredAttendance.length > 0 ? (
        <ul className="list-group">
          {filteredAttendance.map((record) => (
            <li key={record._id} className="list-group-item">
              <strong>{record.studentName}</strong> - {record.date}: {record.status}
            </li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No attendance records found.</p>
      )}
    </div>
  );
};

export default Attendance;
