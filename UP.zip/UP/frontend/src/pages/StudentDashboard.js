import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [marks, setMarks] = useState([]);
  const [timetable, setTimetable] = useState([]);

  useEffect(() => {
    // ✅ Fetch student marks
    const fetchMarks = async () => {
      try {
        const res = await api.get("/student/marks");
        setMarks(res.data);
      } catch (error) {
        console.error("❌ Error fetching marks:", error.response?.data?.msg || error.message);
      }
    };

    // ✅ Fetch timetable
    const fetchTimetable = async () => {
      try {
        const res = await api.get("/student/timetable");
        setTimetable(res.data);
      } catch (error) {
        console.error("❌ Error fetching timetable:", error.response?.data?.msg || error.message);
      }
    };

    fetchMarks();
    fetchTimetable();
  }, []);

  // ✅ Logout function
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  return (
    <div className="container mt-4">
      <h2>Welcome, Student</h2>
      <p>You can view your marks, download materials, and check attendance.</p>

      {/* ✅ Quick Actions */}
      <div className="d-flex gap-3">
        <button className="btn btn-success" onClick={() => navigate("/view-marks")}>
          📊 View Marks
        </button>
        <button className="btn btn-primary" onClick={() => navigate("/download-materials")}>
          📥 Download Course Materials
        </button>
      </div>

      {/* ✅ Notices & Timetable */}
      <div className="mt-4">
        <h4>📅 Notices & Timetable</h4>
        <button className="btn btn-info" onClick={() => navigate("/view-notices")}>
          📰 View Notices
        </button>
        <button className="btn btn-warning" onClick={() => navigate("/view-timetable")}>
          📅 View Timetable
        </button>
      </div>

      {/* ✅ Student Marks */}
      <div className="mt-4">
        <h4>📊 Your Marks</h4>
        {marks.length > 0 ? (
          <ul>
            {marks.map((mark) => (
              <li key={mark._id}>
                {mark.subject}: {mark.score} / {mark.total}
              </li>
            ))}
          </ul>
        ) : (
          <p>⚠️ No marks available.</p>
        )}
      </div>

      {/* ✅ Student Timetable */}
      <div className="mt-4">
        <h4>📅 Your Timetable</h4>
        {timetable.length > 0 ? (
          <ul>
            {timetable.map((entry) => (
              <li key={entry._id}>
                {entry.day} - {entry.subject} ({entry.startTime} - {entry.endTime})
              </li>
            ))}
          </ul>
        ) : (
          <p>⚠️ No timetable available.</p>
        )}
      </div>

      {/* ✅ Logout Button */}
      <button className="btn btn-danger mt-4" onClick={handleLogout}>
        🚪 Logout
      </button>
    </div>
  );
};

export default StudentDashboard;
