import React, { useState, useEffect } from "react";
import api from "../api/api";

const ViewNotices = () => {
  const [notices, setNotices] = useState([]);
  const [priorityFilter, setPriorityFilter] = useState("all");

  useEffect(() => {
    fetchNotices();
  }, []);

  // ✅ Fetch Notices from API
  const fetchNotices = async () => {
    try {
      const response = await api.get("/notices");
      setNotices(response.data);
    } catch (error) {
      console.error("❌ Error fetching notices:", error.response?.data?.msg || error.message);
    }
  };

  // ✅ Format Date Function
  const formatDate = (dateString) => {
    const options = { day: "2-digit", month: "2-digit", year: "numeric" };
    return new Date(dateString).toLocaleDateString("en-GB", options);
  };

  // ✅ Filter Notices by Priority
  const filteredNotices = notices.filter((notice) =>
    priorityFilter === "all" ? true : notice.priority === priorityFilter
  );

  return (
    <div className="container mt-5">
      <h2>📢 Notices</h2>

      {/* ✅ Priority Filter */}
      <select className="form-control mb-3" onChange={(e) => setPriorityFilter(e.target.value)}>
        <option value="all">All Notices</option>
        <option value="urgent">🚨 Urgent</option>
        <option value="general">📋 General</option>
        <option value="info">ℹ️ Info</option>
      </select>

      {/* ✅ Display Notices */}
      {filteredNotices.length > 0 ? (
        <ul className="list-group">
          {filteredNotices.map((notice) => (
            <li key={notice._id} className="list-group-item">
              <strong>{notice.priority.toUpperCase()}</strong> - {notice.title}
              <p>{notice.description}</p>
              <small>📅 {formatDate(notice.date)}</small>
              {notice.fileUrl && (
                <a href={notice.fileUrl} download className="btn btn-primary btn-sm float-end">
                  ⬇️ Download Attachment
                </a>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <p>⚠️ No notices available.</p>
      )}
    </div>
  );
};

export default ViewNotices;
