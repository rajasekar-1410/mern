import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/api";

const Login = () => {
  const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ role: "student", identifier: "", password: "" });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  // ✅ Handle input changes
  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  // ✅ Handle Login
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/auth/login", {
        identifier: credentials.identifier,
        password: credentials.password,
        role: credentials.role,
      });
      
      console.log("✅ API Response:", response.data);
      setMessage("✅ Login Successful!");
  
      // ✅ Store token and user data in localStorage
      localStorage.setItem("token", response.data.token);
      localStorage.setItem("userRole", response.data.user.role);
  
      // ✅ Redirect based on role
      if (credentials.role === "admin") {
        navigate("/admin-dashboard");
      } else if (credentials.role === "faculty") {
        navigate("/faculty-dashboard");
      } else {
        navigate("/student-dashboard");
      }
  
    } catch (error) {
      console.error("❌ API Error:", error.response?.data?.msg || "Unknown error");
      setMessage("❌ Login failed! Please check your credentials.");
    }
  };
  

  return (
    <div className="container mt-5">
      <h2>🔐 Login</h2>
      {message && <p style={{ color: message.includes("❌") ? "red" : "green" }}>{message}</p>}
      <form onSubmit={handleLogin}>
        <select name="role" onChange={handleChange} value={credentials.role} className="form-control mb-2">
          <option value="student">Student</option>
          <option value="faculty">Faculty</option>
          <option value="admin">Admin</option>
        </select>
        <input
          type="text"
          name="identifier"
          placeholder="Register Number / Faculty ID / Email"
          value={credentials.identifier}
          onChange={handleChange}
          className="form-control mb-2"
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={credentials.password}
          onChange={handleChange}
          className="form-control mb-2"
        />
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
      {/* ✅ Signup Button for Admins */}
      <div className="mt-3">
        <p>New Admin? <button onClick={() => navigate("/signup-admin")} className="btn btn-link">Signup Here</button></p>
      </div>
    </div>
  );
};

export default Login;
